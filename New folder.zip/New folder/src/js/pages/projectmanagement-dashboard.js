import { docReady } from '../utils';
import zeroBurnOutChartInit from '../theme/charts/echarts/zero-burnout-chart';
import issuesDiscoveredChartInit from '../theme/charts/echarts/issues-discovered-chart';

docReady(zeroBurnOutChartInit);
docReady(issuesDiscoveredChartInit);
