import { docReady } from '../utils';
import totalSalesChartInit from '../theme/charts/echarts/total-sales-chart';
import newCustomersChartsInit from '../theme/charts/echarts/new-customers';
import topCouponsChartInit from '../theme/charts/echarts/top-coupons-chart';
import projectionVsActualChartInit from '../theme/charts/echarts/projection-vs-actual-chart';
import returningCustomerChartInit from '../theme/charts/echarts/returning-customer-chart';
// import leafletTopRegionsInit from '../theme/leaflet-top-regions';
import payingCustomerChartInit from '../theme/charts/chartjs/PayingCustomerChart';
import leafletInit from '../theme/leaflet-top-regions.js';

docReady(totalSalesChartInit);
docReady(newCustomersChartsInit);
docReady(topCouponsChartInit);
docReady(projectionVsActualChartInit);
docReady(returningCustomerChartInit);
// docReady(leafletTopRegionsInit);
docReady(payingCustomerChartInit);
docReady(leafletInit);
