/* eslint-disable no-new */
import { getData, resize } from '../utils';
/*-----------------------------------------------
|                    Swiper
-----------------------------------------------*/

const productsFilterInit = () => {
  const filterBtn = document.querySelector('[data-filter-column]');
  const filterCol = document.querySelector('.filter-column');
  const filterColBackdrop = document.querySelector('.filter-column-backdrop');
  const filterColCloseBtn = document.querySelector(
    '[data-filter-column-close]'
  );

  if (filterCol) {
    const showFilterCol = () => {
      filterCol.classList.add('show');
      document.body.style.overflow = 'hidden';
    };
    const hideFilterCol = () => {
      filterCol.classList.remove('show');
      document.body.style.removeProperty('overflow');
    };
    filterBtn.addEventListener('click', () => {
      showFilterCol();
    });
    filterColCloseBtn.addEventListener('click', () => {
      hideFilterCol();
    });
    filterColBackdrop.addEventListener('click', () => {
      hideFilterCol();
    });
  }
};

export default productsFilterInit;
