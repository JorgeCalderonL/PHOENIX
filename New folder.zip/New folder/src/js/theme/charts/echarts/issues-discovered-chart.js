import { getColor, getData, resize } from '../../../utils';
import { echartSetOption } from './echarts-utils';

// dayjs.extend(advancedFormat);

/* -------------------------------------------------------------------------- */
/*                             Echarts Total Sales                            */
/* -------------------------------------------------------------------------- */

const issuesDiscoveredChartInit = () => {
  const issuesDiscoveredChartEl = document.querySelector('.echart-issue-chart');

  if (issuesDiscoveredChartEl) {
    const userOptions = getData(issuesDiscoveredChartEl, 'echarts');
    const chart = window.echarts.init(issuesDiscoveredChartEl);

    const getDefaultOptions = () => ({
      color: [
        getColor('info-300'),
        getColor('warning-300'),
        getColor('danger-300'),
        getColor('success-300'),
        getColor('primary')
      ],
      tooltip: {
        trigger: 'item'
      },
      responsive: true,
      maintainAspectRatio: false,

      series: [
        {
          name: 'Tasks assigned to me',
          type: 'pie',
          radius: ['48%', '90%'],
          startAngle: 30,
          avoidLabelOverlap: false,
          label: {
            show: false,
            position: 'center'
          },
          emphasis: {
            label: {
              show: false,
              fontSize: '12.8',
              fontWeight: 'semi-bold'
            }
          },
          labelLine: {
            show: false
          },
          data: [
            { value: 56, name: 'QA & Testing' },
            { value: 24, name: 'R & D' },

            { value: 36, name: 'customer queries' },
            { value: 78, name: 'Product design' },
            { value: 63, name: 'Development' }
          ]
        }
      ],
      grid: {
        bottom: 0,
        top: 0,
        left: 0,
        right: 0,
        containLabel: false
      }
    });

    echartSetOption(chart, userOptions, getDefaultOptions);

    resize(() => {
      chart.resize();
    });
  }
};

export default issuesDiscoveredChartInit;
