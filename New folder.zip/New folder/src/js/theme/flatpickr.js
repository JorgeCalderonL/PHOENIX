import { getData } from '../utils';
import flatpickr from 'flatpickr';

/* -------------------------------------------------------------------------- */
/*                                  Flatpickr                                 */
/* -------------------------------------------------------------------------- */

const flatpickrInit = () => {
  document.querySelectorAll('.datetimepicker').forEach(item => {
    flatpickr(item, getData(item, 'options'));
  });
};

export default flatpickrInit;
