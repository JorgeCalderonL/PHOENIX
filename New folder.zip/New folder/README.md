## Phoenix, a theme by ThemeWagon team.

---

Get the figma design file here:
[https://www.figma.com/file/SJW1m8p4WiRcqJgDkSndAD/Phoenix-Distributed-(v1.3.0)?node-id=979%3A13322](<https://www.figma.com/file/SJW1m8p4WiRcqJgDkSndAD/Phoenix-Distributed-(v1.3.0)?node-id=979%3A13322>)
